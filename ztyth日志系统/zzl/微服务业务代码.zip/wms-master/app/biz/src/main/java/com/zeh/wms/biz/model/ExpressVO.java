package com.zeh.wms.biz.model;

import lombok.Getter;
import lombok.Setter;

/**
 * @author hzy24985
 * @version $Id: ExpressVO, v 0.1 2018/3/10 17:01 hzy24985 Exp $
 */
@Getter
@Setter
public class ExpressVO extends BaseVO  {
    private String code;

    private String name;
}
